public class Item {
    
    private int quantidade;

    
    public Item(int quantidade) {
        
        this.quantidade = quantidade;
    }

    
    public int getQuantidade() {
        
        return quantidade;
    }

    
    public void setQuantidade(int quantidade) {
        
        this.quantidade = quantidade;
    }
}