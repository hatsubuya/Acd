

public enum Descricao
{
    ARROZ,FEIJAO,FARINHA,LEITE;
}