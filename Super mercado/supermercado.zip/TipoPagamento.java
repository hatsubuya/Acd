

public enum TipoPagamento
{
    DINHEIRO,CHEQUE,CARTÃO;
}