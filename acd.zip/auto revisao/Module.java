public class Module {

    private String code;

    public Module(String moduleCode) {
    
        this.code = moduleCode;
        
    }
}