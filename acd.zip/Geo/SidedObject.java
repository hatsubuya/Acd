public interface SidedObject {
    
    public abstract int displaySides();
    
}