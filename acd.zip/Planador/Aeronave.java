public class Aeronave {
    
    protected double rota;

    
    public void desviar(double angulo) {
        
        rota += angulo;
        
    }
}