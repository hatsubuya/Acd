public interface Autentificavel {

    boolean autentica(String senha);
    
}