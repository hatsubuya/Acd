public interface Pagavel {
    
    double valorPagto();
    
}