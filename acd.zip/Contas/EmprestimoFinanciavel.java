public interface EmprestimoFinanciavel 
{
    double valorEmprestimo();
}