public interface PilhaInteiros {
    
    void empilha(int n);
    
    void desempilha();
    
    boolean vazia();
    
    int consulta();
    
}