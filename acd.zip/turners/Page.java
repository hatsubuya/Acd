public class Page implements Turner {
    
    @Override
    public String turn() {
        
        return "Indo para a próxima página";
        
    }
}