public interface Turner {
    
    String turn();
    
}