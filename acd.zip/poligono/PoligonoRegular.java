public class PoligonoRegular {
    
    private int numeroLados;
    
    private double medidaLado;
    
     public int getNumeroLados() {
         
        return numeroLados;
        
    }

    public void setNumeroLados(int numeroLados) {
        
        this.numeroLados = numeroLados;
        
    }

    public double getMedidaLado() {
        
        return medidaLado;
        
    }

    public void setMedidaLado(double medidaLado) {
        
        this.medidaLado = medidaLado;
        
    }


    public double calcularArea() {
        
        return 0;
        
    }
}