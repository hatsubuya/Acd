public abstract class Circuit {
    
    public abstract double getResistance();
    
}